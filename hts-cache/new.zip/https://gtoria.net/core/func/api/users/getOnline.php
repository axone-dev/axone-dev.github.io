<div class="panel panel-primary">
<div class="panel-heading" id="count"><span class="fa fa-user"></span> Users currently online</div>
<div class="panel-body">
<a style="color:inherit;text-decoration: none;" href="/user/profile/Storm">Storm </a><a style="color:inherit;text-decoration: none;" href="/user/profile/Wizardox">Wizardox </a><a style="color:inherit;text-decoration: none;" href="/user/profile/Love">Love </a><a style="color:inherit;text-decoration: none;" href="/user/profile/DeezNuts">DeezNuts </a><a style="color:inherit;text-decoration: none;" href="/user/profile/moha">moha </a><script>$("#count").html("<span class=\"fa fa-user\"></span> Users currently online (5)");</script></div>
</div>